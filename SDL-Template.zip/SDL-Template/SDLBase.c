#include <stdlib.h>
#include <stdio.h>
#include "SDL2/SDL.h"


/* Gli esempi sono una rielaborazione di quelli che si possono trovare a questi indirizzi:
   https://thenumbat.github.io/cpp-course/sdl2/04/04.html
*/
int main( int argc, char* args[] ) {
    // Pointers to our window and surface and renderer
	SDL_Surface* winSurface = NULL;
	SDL_Window* window = NULL;
	SDL_Renderer* renderer;
	int i;
	SDL_Rect r;  // a rectangle

	// Initialize SDL. SDL_Init will return -1 if it fails.
	if ( SDL_Init( SDL_INIT_EVERYTHING ) < 0 ) {
		printf("Error initializing SDL: %d\n", SDL_GetError());
		system("pause");
		// End the program
		return 1;
	} 

	// Create our window
	window = SDL_CreateWindow( "Esempio di uso di SDL", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, 1280, 720, SDL_WINDOW_SHOWN );

	// Make sure creating the window succeeded
	if ( !window ) {
		printf("Error creating window: %d\n", SDL_GetError());
		system("pause");
		// End the program
		return 1;
	}

    renderer = SDL_CreateRenderer( window, -1, SDL_RENDERER_ACCELERATED );
	if ( !renderer ) {
		printf("Error creating renderer: %d\n", SDL_GetError());
		system("pause");
		return 1;
	}

	// Clear the window to white
	SDL_SetRenderDrawColor( renderer, 255, 255, 255, 255 );
	SDL_RenderClear( renderer );
	
	// Set drawing color to black
	SDL_SetRenderDrawColor( renderer, 0, 0, 0, 255 );
    for(i=0;i<10;i++)
	    SDL_RenderDrawPoint(renderer, 100+10*i, 100 );

	// Set drawing color to red
	SDL_SetRenderDrawColor( renderer, 255, 0, 0, 255 );
    SDL_RenderDrawLine( renderer, 200, 200, 300, 400 );


    // Set drawing color to blue
	SDL_SetRenderDrawColor( renderer, 0, 0, 255, 255 );
    r.x = 600;
	r.y = 200;
	r.w = 50;
	r.h = 100;
	SDL_RenderDrawRect( renderer, &r );

    // Update window
	SDL_RenderPresent( renderer );
	

	// Wait
	system("pause");

	// Destroy the renderer and the windows
	SDL_DestroyRenderer ( renderer ); 
	SDL_DestroyWindow( window );

	// Quit SDL
	SDL_Quit();
	
	// End the program
	return 0;
}
